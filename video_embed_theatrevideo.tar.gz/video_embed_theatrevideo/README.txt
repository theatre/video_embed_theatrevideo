This module provides theatre-video.net handler for video embed field module
now with this module you can add embed videos from http://www.theatre-video.net
to your website
it also can get thumbnail image from theatre-video.net
